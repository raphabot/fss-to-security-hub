const AWS = require('aws-sdk');
const uuid = require('uuid');

// prepareSecurityHubFindings = (fssFindings) => {
//   return fssFindings.reduce( (findings, finding) => {
//     findings.Findings.push({
//       "AwsAccountId": "218213273676",
//       "CreatedAt": "2020-10-29T13:58:32.933Z",
//       "Description": "Malware found!",
//       "GeneratorId": "FSS",
//       "Id": "218213273676/2",
//       "ProductArn": "arn:aws:securityhub:us-east-1:218213273676:product/218213273676/default",
//       "SchemaVersion": "2018-10-08",
//       "Resources": [
//         {
//           "Id": "that-bucket",
//           "Type": "AwsS3Object"
//         }
//       ],
//       "Malware": [ 
//         { 
//             "Name": finding.malware,
//             "Path": "object",
//             "State": "OBSERVED",
//             "Type": "POTENTIALLY_UNWANTED"
//         }
//     ],
//       "Severity": {
//         "Label": "HIGH"
//       },
//       "Title": "S3 Object had malware detected by FSS.",
//       "Types": [
//         "Software and Configuration Checks/Vulnerabilities/CVE"
//       ],
//       "UpdatedAt": "2020-10-29T13:58:32.933Z"
//     }), {Findings: []}
//   });
// };

parseDetectionPath = (path) => {
  const bucket = path.substring(8, path.indexOf('.s3.'));
  const key = path.split('/').slice(3).join('/');
  return {
    bucket,
    key
  };
};

publishToSecurityHub = async (securityhub, securityHubArn, accountId, malwareName, bucket, key ) => {
  const date = new Date().toISOString();
  const params = {
    Findings : [
      {
        AwsAccountId: accountId,
        CreatedAt: date,
        Description: "Malware found!",
        GeneratorId: "FSS",
        Id: `${accountId}/${uuid.v4()}`,
        ProductArn: securityHubArn,
        SchemaVersion: "2018-10-08",
        Resources: [
          {
            Id: key,
            Type: "AwsS3Object"
          },
          {
            Id: bucket,
            Type: "AwsS3Bucket"
          },
        ],
        Malware: [ 
          { 
              Name: malwareName,
              Path: key,
              State: "OBSERVED",
              Type: "POTENTIALLY_UNWANTED"
          }
      ],
        Severity: {
          Label: "HIGH"
        },
        Title: "S3 Object had malware detected by FSS.",
        Types: [
          "Unusual Behaviors/Data"
        ],
        UpdatedAt: date
      }
    ]
  };
  try {
    console.log(params);
    const result = await securityhub.batchImportFindings(params).promise();
    console.log(result);
    return result;
  } catch (error) {
    console.error(error);
    return error;
  }
};

exports.handler = async (event) => {
  const securityHubArn = process.env.SECURITY_HUB_ARN;
  const accountId = process.env.ACCOUNT_ID;
  const securityhub = new AWS.SecurityHub();
  return Promise.all(event.Records.map(async (record) => {
    console.log(record);
    const message = JSON.parse(record.Sns.Message);
    const findings = message.scanning_result.Findings;
    
    const results = [];
    
    if (findings) {
      const malwareName = findings[0].malware;
      const path = parseDetectionPath(message.file_url);
      console.log(path);
      const findingResult = await publishToSecurityHub(securityhub, securityHubArn, accountId, malwareName, path.bucket, path.key);
      console.log('findingResult: ', findingResult);
      // results.push(findingResult);
      // console.log(prepareSecurityHubFindings(findings));
    }
  }));
  return results;
};